as3-rest-client
===============

REST API Client for ActionScript 3
